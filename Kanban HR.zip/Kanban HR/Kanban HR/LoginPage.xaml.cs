﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kanban_HR
{
	/// <summary>
	/// Логика взаимодействия для LoginPage.xaml
	/// </summary>
	public partial class LoginPage : Page
	{
		public LoginPage()
		{
			InitializeComponent();
		}

		private void LoginButton_Click(object sender, RoutedEventArgs e)
		{
			MessageBox.Show("Вход в систему", "Информация",
				MessageBoxButton.OK, MessageBoxImage.Information);
		}

		private void RegisterLinkText_MouseDown(object sender, MouseButtonEventArgs e)
		{
			RegistrationPage registrationPage = new RegistrationPage();
			this.NavigationService.Navigate(registrationPage);
		}
	}
}
