﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kanban_HR
{
	/// <summary>
	/// Логика взаимодействия для RegistrationPage.xaml
	/// </summary>
	public partial class RegistrationPage : Page
	{
		public RegistrationPage()
		{
			InitializeComponent();
		}

		private void RegisterButton_Click(object sender, RoutedEventArgs e)
		{
			if (PasswordBox.Password != ConfirmPasswordBox.Password)
			{
				MessageBox.Show("Пароли не совпадают!", "Ошибка",
					MessageBoxButton.OK, MessageBoxImage.Error);
				return;
			}
			if (string.IsNullOrWhiteSpace(FullNameTextBox.Text) ||
				string.IsNullOrWhiteSpace(EmailTextBox.Text) ||
				string.IsNullOrWhiteSpace(PasswordBox.Password))
			{
				MessageBox.Show("Заполните все поля!", "Ошибка",
					MessageBoxButton.OK, MessageBoxImage.Error);
				return;
			}

			MessageBox.Show("Регистрация в разработке", "Информация",
				MessageBoxButton.OK, MessageBoxImage.Information);
		}
		private void LoginLinkText_MouseDown(object sender, MouseButtonEventArgs e)
		{
			LoginPage loginPage = new LoginPage();
			this.NavigationService.Navigate(loginPage);
		}
	}
}
